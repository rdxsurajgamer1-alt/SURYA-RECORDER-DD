package com.ultra.screenrecorder

import android.app.*
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.media.MediaFormat
import android.media.MediaCodec
import java.io.File
import java.nio.ByteBuffer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenRecordService : Service() {
    companion object {
        const val ACTION_START = "usr.START"
        const val ACTION_STOP = "usr.STOP"
        const val ACTION_SHOW_OVERLAY = "usr.OVERLAY"
        const val ACTION_PAUSE = "usr.PAUSE"
        const val ACTION_RESUME = "usr.RESUME"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "projectionData"
        const val EXTRA_RESOLUTION = "resolution"
        const val EXTRA_FPS = "fps"
        const val EXTRA_BITRATE = "bitrate"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_COUNTDOWN = "countdown"
        const val EXTRA_RATIO = "ratio"
        private const val CHANNEL = "usr_recording"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var callback: MediaProjection.Callback? = null
    private var recorder: MediaRecorder? = null
    private var audioCapture: AudioCaptureEngine? = null
    private var videoTemp: File? = null
    private var audioTemp: File? = null
    private var display: VirtualDisplay? = null
    private var overlay: LinearLayout? = null
    private var bubble: TextView? = null
    private var outputUri: Uri? = null
    private var recordingStarted = false
    private var finalizing = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var countdownTask: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin(intent)
            ACTION_STOP -> finishRecording()
            ACTION_SHOW_OVERLAY -> showOverlay()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
        }
        return START_NOT_STICKY
    }

    private fun begin(i: Intent) {
        try {
            val audioMode = i.getIntExtra(EXTRA_AUDIO, 0)
            if ((audioMode == 2 || audioMode == 3) && Build.VERSION.SDK_INT < 29) {
                Toast.makeText(this, "Internal audio requires Android 10 or newer", Toast.LENGTH_LONG).show()
                stopSelf()
                return
            }
            createChannel()
            val notification = Notification.Builder(this, CHANNEL)
                .setContentTitle("Ultra Screen Recorder")
                .setContentText("Screen recording is active")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true).build()
            if (Build.VERSION.SDK_INT >= 29) {
                val serviceTypes = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    (if (audioMode == 0 || audioMode == 3) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
                startForeground(NOTIFICATION_ID, notification, serviceTypes)
            } else startForeground(NOTIFICATION_ID, notification)

            val code = i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            else {
                @Suppress("DEPRECATION") i.getParcelableExtra(EXTRA_DATA)
            } ?: error("Screen capture permission missing")

            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    finishRecording()
                }
            }
            projection!!.registerCallback(callback!!, mainHandler)

            val metrics = resources.displayMetrics
            val screenW = metrics.widthPixels
            val screenH = metrics.heightPixels
            val density = metrics.densityDpi
            val longest = maxOf(screenW, screenH)
            val preset = i.getIntExtra(EXTRA_RESOLUTION, 0)
            val wanted = when (preset) { 1 -> 1280; 2 -> 1920; 3 -> 2560; 4 -> 3840; else -> longest }
            val scale = minOf(1f, wanted.toFloat() / longest)
            val width = even((screenW * scale).toInt())
            val height = even((screenH * scale).toInt())
            val fps = when (i.getIntExtra(EXTRA_FPS, 0)) { 1 -> 20; 2 -> 60; 3 -> 90; 4 -> 120; else -> 30 }
            val bitRate = when (i.getIntExtra(EXTRA_BITRATE, 0)) {
                1 -> 4_000_000; 2 -> 12_000_000; 3 -> 16_000_000
                4 -> 24_000_000; 5 -> 40_000_000; else -> 8_000_000
            }
            val delay = when (i.getIntExtra(EXTRA_COUNTDOWN, 0)) { 1 -> 5000L; 2 -> 10000L; 3 -> 0L; else -> 3000L }

            countdownTask = Runnable {
                if (finalizing) return@Runnable
                try {
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "Screen_$stamp.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        if (Build.VERSION.SDK_INT >= 29) {
                            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Ultra Screen Recorder")
                            put(MediaStore.Video.Media.IS_PENDING, 1)
                        }
                    }
                    outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("Could not create video file in Movies")
                    videoTemp = File(cacheDir, "usr_video_$stamp.mp4")
                    audioTemp = File(cacheDir, "usr_audio_$stamp.m4a")

                    recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else {
                        @Suppress("DEPRECATION") MediaRecorder()
                    }
                    recorder!!.apply {
                        setVideoSource(MediaRecorder.VideoSource.SURFACE)
                        setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                        setOutputFile(videoTemp!!.absolutePath)
                        setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                        setVideoSize(width, height)
                        setVideoFrameRate(fps)
                        setVideoEncodingBitRate(bitRate)
                        prepare()
                    }
                    display = projection?.createVirtualDisplay(
                        "UltraScreenRecorder", width, height, density,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        recorder!!.surface, null, null
                    )
                    recorder!!.start()
                    recordingStarted = true
                    if (audioMode != 1) {
                        audioCapture = AudioCaptureEngine(projection!!, audioMode, audioTemp!!)
                        audioCapture!!.start()
                    }
                    showOverlay()
                } catch (e: Exception) {
                    Toast.makeText(this, "Recording start failed: ${e.message}", Toast.LENGTH_LONG).show()
                    finishRecording()
                }
            }
            mainHandler.postDelayed(countdownTask!!, delay)
        } catch (e: Exception) {
            Toast.makeText(this, "Capture error: ${e.message}", Toast.LENGTH_LONG).show()
            finishRecording()
        }
    }

    private fun muxTracks(video: File, audio: File?, output: java.io.FileDescriptor) {
        val muxer = MediaMuxer(output, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val extractors = mutableListOf<MediaExtractor>()
        var started = false
        try {
            val videoExtractor = MediaExtractor().also { it.setDataSource(video.absolutePath); extractors.add(it) }
            val videoTrack = (0 until videoExtractor.trackCount).firstOrNull {
                videoExtractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
            } ?: error("Video track missing")
            val outVideo = muxer.addTrack(videoExtractor.getTrackFormat(videoTrack))
            videoExtractor.selectTrack(videoTrack)

            var audioExtractor: MediaExtractor? = null
            var outAudio = -1
            if (audio != null && audio.exists() && audio.length() > 0) {
                try {
                    audioExtractor = MediaExtractor().also { it.setDataSource(audio.absolutePath); extractors.add(it) }
                    val audioTrack = (0 until audioExtractor.trackCount).firstOrNull {
                        audioExtractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
                    }
                    if (audioTrack != null) {
                        outAudio = muxer.addTrack(audioExtractor.getTrackFormat(audioTrack))
                        audioExtractor.selectTrack(audioTrack)
                    } else {
                        audioExtractor.release(); extractors.remove(audioExtractor); audioExtractor = null
                    }
                } catch (_: Exception) {
                    try { audioExtractor?.release() } catch (_: Exception) {}
                    audioExtractor?.let { extractors.remove(it) }
                    audioExtractor = null
                }
            }
            muxer.start(); started = true
            if (audioExtractor != null && outAudio >= 0) {
                copyInterleaved(videoExtractor, outVideo, audioExtractor, outAudio, muxer)
            } else {
                copySamples(videoExtractor, outVideo, muxer)
            }
        } finally {
            if (started) try { muxer.stop() } catch (_: Exception) {}
            try { muxer.release() } catch (_: Exception) {}
            extractors.forEach { try { it.release() } catch (_: Exception) {} }
        }
    }

    private fun copySamples(extractor: MediaExtractor, track: Int, muxer: MediaMuxer) {
        val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            info.set(0, size, extractor.sampleTime, extractor.sampleFlags)
            muxer.writeSampleData(track, buffer, info)
            extractor.advance()
        }
    }

    private fun copyInterleaved(video: MediaExtractor, videoTrack: Int,
                                audio: MediaExtractor, audioTrack: Int, muxer: MediaMuxer) {
        val videoBuffer = ByteBuffer.allocate(2 * 1024 * 1024)
        val audioBuffer = ByteBuffer.allocate(256 * 1024)
        val info = MediaCodec.BufferInfo()
        var videoDone = false
        var audioDone = false
        while (!videoDone || !audioDone) {
            val takeVideo = !videoDone && (audioDone || video.sampleTime <= audio.sampleTime)
            val extractor = if (takeVideo) video else audio
            val buffer = if (takeVideo) videoBuffer else audioBuffer
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) {
                if (takeVideo) videoDone = true else audioDone = true
            } else {
                info.set(0, size, extractor.sampleTime, extractor.sampleFlags)
                muxer.writeSampleData(if (takeVideo) videoTrack else audioTrack, buffer, info)
                extractor.advance()
            }
        }
    }

    private fun even(value: Int) = (value.coerceAtLeast(2) / 2) * 2

    private fun finishRecording() {
        if (finalizing) return
        finalizing = true
        countdownTask?.let { mainHandler.removeCallbacks(it) }
        countdownTask = null

        // Stop encoder first so MP4 trailer/index is written before publishing the file.
        var stoppedCleanly = false
        try {
            if (recordingStarted) {
                recorder?.stop()
                stoppedCleanly = true
            }
        } catch (_: Exception) {
            stoppedCleanly = false
        }
        recordingStarted = false
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { display?.release() } catch (_: Exception) {}
        display = null

        try { audioCapture?.stop() } catch (e: Exception) {
            Toast.makeText(this, "Audio capture failed: ${e.message}. Video will be saved without audio.", Toast.LENGTH_LONG).show()
        }
        audioCapture = null
        val uri = outputUri
        if (uri != null) {
            try {
                if (stoppedCleanly && videoTemp?.exists() == true) {
                    val descriptor = contentResolver.openFileDescriptor(uri, "w") ?: error("Could not open final video")
                    descriptor.use { muxTracks(videoTemp!!, audioTemp?.takeIf { it.exists() }, it.fileDescriptor) }
                    val publish = ContentValues().apply {
                        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.IS_PENDING, 0)
                    }
                    contentResolver.update(uri, publish, null, null)
                    Toast.makeText(this, "वीडियो Movies/Ultra Screen Recorder में सेव हो गया", Toast.LENGTH_LONG).show()
                } else {
                    contentResolver.delete(uri, null, null)
                    Toast.makeText(this, "रिकॉर्डिंग पूरी नहीं हुई; अधूरी फाइल हटाई गई", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                try { contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                Toast.makeText(this, "Video finalize failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        try { videoTemp?.delete() } catch (_: Exception) {}
        try { audioTemp?.delete() } catch (_: Exception) {}
        videoTemp = null
        audioTemp = null
        outputUri = null
        try { callback?.let { projection?.unregisterCallback(it) } } catch (_: Exception) {}
        callback = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        removeOverlay()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this) || overlay != null || bubble != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6, 6, 6, 6)
            setBackgroundColor(0xEE292333.toInt())
        }
        val pause = Button(this).apply {
            text = "Ⅱ Pause"
            isAllCaps = false
            setOnClickListener { pauseRecording() }
        }
        val stop = Button(this).apply {
            text = "■ रोकें"
            isAllCaps = false
            setOnClickListener { finishRecording() }
        }
        val hide = Button(this).apply {
            text = "— Hide"
            isAllCaps = false
            setOnClickListener { collapseToBubble() }
        }
        val exit = Button(this).apply {
            text = "✕"
            contentDescription = "Exit recorder"
            isAllCaps = false
            setOnClickListener { finishRecording() }
        }
        panel.addView(pause)
        panel.addView(stop)
        panel.addView(hide)
        panel.addView(exit)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        try { wm.addView(panel, params); overlay = panel } catch (_: Exception) {}
    }


    private fun pauseRecording() {
        if (!recordingStarted) return
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                recorder?.pause()
                overlay?.getChildAt(0)?.let { view ->
                    (view as? Button)?.apply { text = "▶ Resume"; setOnClickListener { resumeRecording() } }
                }
                Toast.makeText(this, "Recording paused", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Pause failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun resumeRecording() {
        if (!recordingStarted) return
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                recorder?.resume()
                overlay?.getChildAt(0)?.let { view ->
                    (view as? Button)?.apply { text = "Ⅱ Pause"; setOnClickListener { pauseRecording() } }
                }
                Toast.makeText(this, "Recording resumed", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Resume failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun collapseToBubble() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        val mini = TextView(this).apply {
            text = "●"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xEE292333.toInt())
            setPadding(16, 10, 16, 10)
            contentDescription = "Show recorder controls"
            setOnClickListener { restoreOverlay() }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        try { wm.addView(mini, params); bubble = mini } catch (_: Exception) {}
    }

    private fun restoreOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null
        showOverlay()
    }

    private fun removeOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        bubble = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        if (!finalizing && (recorder != null || projection != null || outputUri != null)) finishRecording()
        super.onDestroy()
    }
}
