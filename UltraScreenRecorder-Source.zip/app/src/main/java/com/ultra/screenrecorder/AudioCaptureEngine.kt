package com.ultra.screenrecorder

import android.media.*
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Process
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/** Captures device playback and/or microphone, encodes AAC into a temporary M4A track. */
internal class AudioCaptureEngine(
    private val projection: MediaProjection,
    private val mode: Int,
    private val output: File
) {
    // MainActivity audio modes: 0=mic, 1=mute, 2=internal, 3=internal+mic.
    private val sampleRate = 44100
    private val channels = 2
    private val channelMask = AudioFormat.CHANNEL_IN_STEREO
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private var internalRecord: AudioRecord? = null
    private var micRecord: AudioRecord? = null
    @Volatile private var failure: Exception? = null

    fun start() {
        require(Build.VERSION.SDK_INT >= 29 || mode == 0) {
            "Internal audio capture requires Android 10 or newer"
        }
        val format = AudioFormat.Builder().setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(channelMask).build()
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT)
        require(minBuffer > 0) { "Unsupported audio format" }
        val bufferSize = max(minBuffer * 2, sampleRate / 5 * channels * 2)

        if (mode == 2 || mode == 3) {
            val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build()
            internalRecord = AudioRecord.Builder().setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize).setAudioPlaybackCaptureConfig(config).build()
        }
        if (mode == 0 || mode == 3) {
            micRecord = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(format).setBufferSizeInBytes(bufferSize).build()
        }
        internalRecord?.startRecording()
        micRecord?.startRecording()
        running.set(true)
        worker = Thread({ encodeLoop(bufferSize) }, "USR-AudioCapture").apply { start() }
    }

    fun stop() {
        running.set(false)
        try { internalRecord?.stop() } catch (_: Exception) {}
        try { micRecord?.stop() } catch (_: Exception) {}
        try { worker?.join(4000) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        try { internalRecord?.release() } catch (_: Exception) {}
        try { micRecord?.release() } catch (_: Exception) {}
        internalRecord = null
        micRecord = null
        worker = null
        failure?.let { throw it }
    }

    private fun encodeLoop(bufferSize: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var track = -1
        try {
            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufferSize)
            }
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            // Keep each PCM chunk small enough for typical AAC encoder input buffers.
            val chunkSamples = 2048
            val internal = ShortArray(chunkSamples)
            val mic = ShortArray(chunkSamples)
            val mixed = ShortArray(chunkSamples)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var ptsUs = 0L
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(10000)
                    if (inIndex >= 0) {
                        val input = codec.getInputBuffer(inIndex)!!
                        input.clear()
                        var samples = 0
                        if (running.get()) {
                            val a = internalRecord?.read(internal, 0, internal.size, AudioRecord.READ_BLOCKING) ?: -1
                            val b = micRecord?.read(mic, 0, mic.size, AudioRecord.READ_BLOCKING) ?: -1
                            samples = when {
                                internalRecord != null && micRecord != null -> minOf(max(0, a), max(0, b))
                                internalRecord != null -> max(0, a)
                                micRecord != null -> max(0, b)
                                else -> 0
                            }
                            for (n in 0 until samples) {
                                val value = (if (internalRecord != null) internal[n].toInt() else 0) +
                                    (if (micRecord != null) mic[n].toInt() else 0)
                                mixed[n] = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                            }
                        }
                        if (samples > 0) {
                            samples = minOf(samples, input.capacity() / 2)
                            val bytes = samples * 2
                            input.asShortBuffer().put(mixed, 0, samples)
                            codec.queueInputBuffer(inIndex, 0, bytes, ptsUs, 0)
                            ptsUs += samples.toLong() * 1_000_000L / (sampleRate * channels)
                        } else {
                            codec.queueInputBuffer(inIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        }
                    }
                }
                val outIndex = codec.dequeueOutputBuffer(info, 10000)
                when {
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    outIndex >= 0 -> {
                        val encoded = codec.getOutputBuffer(outIndex)!!
                        if (info.size > 0 && muxerStarted) {
                            encoded.position(info.offset); encoded.limit(info.offset + info.size)
                            muxer.writeSampleData(track, encoded, info)
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(outIndex, false)
                    }
                }
            }
        } catch (e: Exception) {
            failure = e
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }
}
