package com.ultra.screenrecorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var resolution: Spinner
    private lateinit var fps: Spinner
    private lateinit var bitrate: Spinner
    private lateinit var audio: Spinner
    private lateinit var ratio: Spinner
    private lateinit var countdown: Spinner
    private lateinit var facecam: CheckBox
    private lateinit var touches: CheckBox
    private val captureRequest = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        render()
    }

    private fun render() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(247, 245, 250))
        }
        scroll.addView(box)

        box.addView(TextView(this).apply {
            text = "Ultra Screen Recorder"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(35, 30, 45))
        })
        box.addView(TextView(this).apply {
            text = "रिकॉर्डिंग शुरू करने से पहले अपनी सेटिंग चुनें"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 18)
        })

        resolution = spinner(box, "Resolution", listOf("Device screen", "720p", "1080p", "2K", "4K", "Custom (device limit)"))
        fps = spinner(box, "FPS", listOf("30", "20", "60", "90", "120"))
        bitrate = spinner(box, "Bitrate", listOf("8 Mbps", "4 Mbps", "12 Mbps", "16 Mbps", "24 Mbps", "40 Mbps"))
        audio = spinner(box, "Audio", listOf("Microphone Only", "Mute", "Internal Audio", "Internal Audio + Microphone"))
        ratio = spinner(box, "Recording area", listOf("Full screen", "9:16", "1:1"))
        countdown = spinner(box, "Countdown", listOf("3 seconds", "5 seconds", "10 seconds", "Off"))

        facecam = CheckBox(this).apply { text = "Front camera facecam (camera permission required)" }
        box.addView(facecam)
        touches = CheckBox(this).apply { text = "Show touches (Android developer setting may be required)" }
        box.addView(touches)

        button(box, "START RECORDING / रिकॉर्डिंग शुरू करें") { requestCapture() }
        button(box, "FLOATING MENU / फ्लोटिंग बटन चालू करें") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, ScreenRecordService::class.java).setAction(ScreenRecordService.ACTION_SHOW_OVERLAY))
                Toast.makeText(this, "Floating control enabled", Toast.LENGTH_SHORT).show()
            }
        }
        button(box, "OPEN RECORDINGS / रिकॉर्डिंग देखें") {
            startActivity(Intent(this, GalleryActivity::class.java))
        }
        box.addView(TextView(this).apply {
            text = "Audio: Internal Audio के लिए Android 10+ जरूरी है। कुछ ऐप्स कॉपीराइट/सुरक्षा के कारण अपनी आवाज़ रिकॉर्ड नहीं होने देते। 2K/4K/90/120 FPS केवल समर्थित डिवाइस पर काम करेंगे। Recording area: Full screen, 9:16 और 1:1; इस build में 9:16/1:1 का movable crop-box अभी शामिल नहीं है।"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, 18, 0, 0)
        })
        setContentView(scroll)
    }

    private fun spinner(parent: LinearLayout, title: String, choices: List<String>): Spinner {
        parent.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 10, 0, 3)
        })
        return Spinner(this).also {
            it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
            parent.addView(it)
        }
    }

    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        })
    }

    private fun requestCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenRecordService::class.java).apply {
                action = ScreenRecordService.ACTION_START
                putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenRecordService.EXTRA_DATA, data)
                putExtra(ScreenRecordService.EXTRA_RESOLUTION, resolution.selectedItemPosition)
                putExtra(ScreenRecordService.EXTRA_FPS, fps.selectedItemPosition)
                putExtra(ScreenRecordService.EXTRA_BITRATE, bitrate.selectedItemPosition)
                putExtra(ScreenRecordService.EXTRA_AUDIO, audio.selectedItemPosition)
                putExtra(ScreenRecordService.EXTRA_COUNTDOWN, countdown.selectedItemPosition)
                putExtra(ScreenRecordService.EXTRA_RATIO, ratio.selectedItemPosition)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            if (facecam.isChecked) Toast.makeText(this, "Facecam option saved for next camera integration pass.", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestPermissionsIfNeeded() {
        val asks = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) asks.add(Manifest.permission.RECORD_AUDIO)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) asks.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) asks.add(Manifest.permission.POST_NOTIFICATIONS)
        if (asks.isNotEmpty()) requestPermissions(asks.toTypedArray(), 88)
    }
}
