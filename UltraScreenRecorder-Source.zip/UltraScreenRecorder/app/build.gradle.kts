plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ultra.screenrecorder"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ultra.screenrecorder"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
