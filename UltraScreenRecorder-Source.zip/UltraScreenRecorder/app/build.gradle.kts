plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ultra.screenrecorder"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ultra.screenrecorder"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "2.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
