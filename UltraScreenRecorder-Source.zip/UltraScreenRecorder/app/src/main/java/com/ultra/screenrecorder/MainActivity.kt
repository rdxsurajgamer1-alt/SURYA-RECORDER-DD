package com.ultra.screenrecorder

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Ultra Screen Recorder"
            textSize = 26f
            gravity = Gravity.CENTER
        }

        val status = TextView(this).apply {
            text = "प्रारंभिक ऐप ढाँचा तैयार है।\nBasic app project is ready.\n\nScreen capture and recording controls will be added in the next development step."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        layout.addView(title)
        layout.addView(status)
        setContentView(layout)
    }
}
