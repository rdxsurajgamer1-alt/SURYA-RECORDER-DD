package com.ultra.screenrecorder

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenRecordService : Service() {
    companion object {
        const val ACTION_START = "usr.START"
        const val ACTION_PAUSE = "usr.PAUSE"
        const val ACTION_RESUME = "usr.RESUME"
        const val ACTION_STOP = "usr.STOP"
        const val ACTION_SHOW_OVERLAY = "usr.OVERLAY"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "projectionData"
        const val EXTRA_RESOLUTION = "resolution"
        const val EXTRA_FPS = "fps"
        const val EXTRA_BITRATE = "bitrate"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_COUNTDOWN = "countdown"
        const val EXTRA_RATIO = "ratio"
        private const val CHANNEL = "usr_recording"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var callback: MediaProjection.Callback? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var overlay: LinearLayout? = null
    private var paused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin(intent)
            ACTION_PAUSE -> pause()
            ACTION_RESUME -> resume()
            ACTION_STOP -> finishRecording()
            ACTION_SHOW_OVERLAY -> showOverlay()
        }
        return START_NOT_STICKY
    }

    private fun begin(i: Intent) {
        try {
            createChannel()
            val n = Notification.Builder(this, CHANNEL)
                .setContentTitle("Ultra Screen Recorder")
                .setContentText("Screen recording is active")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true).build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else startForeground(NOTIFICATION_ID, n)

            val code = i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(EXTRA_DATA, Intent::class.java) else {
                @Suppress("DEPRECATION") i.getParcelableExtra(EXTRA_DATA)
            } ?: error("Screen capture permission missing")
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            callback = object : MediaProjection.Callback() {
                override fun onStop() { releaseResources(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            }
            projection!!.registerCallback(callback!!, Handler(Looper.getMainLooper()))

            val metrics = resources.displayMetrics
            val sw = metrics.widthPixels
            val sh = metrics.heightPixels
            val density = metrics.densityDpi
            val longSide = maxOf(sw, sh)
            val resChoice = i.getIntExtra(EXTRA_RESOLUTION, 0)
            val requestedLong = when (resChoice) { 1 -> 1280; 2 -> 1920; 3 -> 2560; 4 -> 3840; else -> longSide }
            val scale = minOf(1f, requestedLong.toFloat() / longSide)
            val w = even((sw * scale).toInt())
            val h = even((sh * scale).toInt())
            val fps = when (i.getIntExtra(EXTRA_FPS, 0)) { 1 -> 20; 2 -> 60; 3 -> 90; 4 -> 120; else -> 30 }
            val bitrate = when (i.getIntExtra(EXTRA_BITRATE, 0)) { 1 -> 4_000_000; 2 -> 12_000_000; 3 -> 16_000_000; 4 -> 24_000_000; 5 -> 40_000_000; else -> 8_000_000 }
            val audioMode = i.getIntExtra(EXTRA_AUDIO, 0)

            val wait = when (i.getIntExtra(EXTRA_COUNTDOWN, 0)) { 1 -> 5000L; 2 -> 10000L; 3 -> 0L; else -> 3000L }
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    val folder = File(getExternalFilesDir(null), "Recordings").apply { mkdirs() }
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val file = File(folder, "Screen_$stamp.mp4")
                    recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else {
                        @Suppress("DEPRECATION") MediaRecorder()
                    }
                    recorder!!.apply {
                        if (audioMode == 0) setAudioSource(MediaRecorder.AudioSource.MIC)
                        setVideoSource(MediaRecorder.VideoSource.SURFACE)
                        setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                        setOutputFile(file.absolutePath)
                        setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                        if (audioMode == 0) setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                        setVideoSize(w, h)
                        setVideoFrameRate(fps)
                        setVideoEncodingBitRate(bitrate)
                        if (audioMode == 0) setAudioEncodingBitRate(128000)
                        prepare()
                    }
                    display = projection?.createVirtualDisplay("UltraScreenRecorder", w, h, density,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder!!.surface, null, null)
                    recorder!!.start()
                    showOverlay()
                } catch (e: Exception) {
                    Toast.makeText(this, "Recording could not start: ${e.message}", Toast.LENGTH_LONG).show()
                    finishRecording()
                }
            }, wait)
        } catch (e: Exception) {
            Toast.makeText(this, "Capture error: ${e.message}", Toast.LENGTH_LONG).show()
            finishRecording()
        }
    }

    private fun even(v: Int) = (v.coerceAtLeast(2) / 2) * 2

    private fun pause() {
        try { if (Build.VERSION.SDK_INT >= 24 && recorder != null && !paused) { recorder!!.pause(); paused = true } } catch (_: Exception) {}
    }
    private fun resume() {
        try { if (Build.VERSION.SDK_INT >= 24 && recorder != null && paused) { recorder!!.resume(); paused = false } } catch (_: Exception) {}
    }
    private fun finishRecording() {
        releaseResources()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    private fun releaseResources() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { callback?.let { projection?.unregisterCallback(it) } } catch (_: Exception) {}
        callback = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        removeOverlay()
    }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this) || overlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xEE292333.toInt())
        }
        fun add(label: String, action: String) {
            root.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { startService(Intent(this@ScreenRecordService, ScreenRecordService::class.java).setAction(action)) }
            })
        }
        add("Pause", ACTION_PAUSE)
        add("Resume", ACTION_RESUME)
        add("Stop", ACTION_STOP)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        try { wm.addView(root, params); overlay = root } catch (_: Exception) {}
    }
    private fun removeOverlay() {
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) {}
        overlay = null
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
    override fun onDestroy() {
        if (recorder != null || projection != null) releaseResources()
        super.onDestroy()
    }
}
