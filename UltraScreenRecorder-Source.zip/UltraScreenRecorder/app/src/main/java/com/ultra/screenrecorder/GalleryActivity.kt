package com.ultra.screenrecorder

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class GalleryActivity : Activity() {
    private val videos = mutableListOf<Pair<Uri, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
        }
        root.addView(TextView(this).apply {
            text = "Ultra Screen Recorder – Recordings"
            textSize = 21f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        })
        val list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        loadVideos(list)
    }

    private fun loadVideos(list: ListView) {
        videos.clear()
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
        val selection = if (Build.VERSION.SDK_INT >= 29) "${MediaStore.Video.Media.RELATIVE_PATH} = ?" else null
        val args = if (selection != null) arrayOf("Movies/Ultra Screen Recorder/") else null
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        try {
            val cursor: Cursor? = contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort
            )
            cursor?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: "Recorded video"
                    videos.add(ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id) to name)
                }
            }
            if (videos.isEmpty()) {
                list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("अभी कोई रिकॉर्डिंग नहीं मिली"))
                list.setOnItemClickListener(null)
            } else {
                list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, videos.map { it.second })
                list.setOnItemClickListener { _, _, position, _ -> play(videos[position].first) }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gallery खोलने में समस्या: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun play(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            Toast.makeText(this, "वीडियो चलाने के लिए कोई player उपलब्ध नहीं है", Toast.LENGTH_LONG).show()
        }
    }
}
