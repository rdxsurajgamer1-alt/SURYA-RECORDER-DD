package com.ultra.screenrecorder

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GalleryActivity : Activity() {
    private lateinit var list: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 20, 18, 20) }
        scroll.addView(list)
        setContentView(scroll)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        list.addView(TextView(this).apply {
            text = "रिकॉर्डिंग गैलरी"
            textSize = 23f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        })
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATE_ADDED
        )
        val selection = if (Build.VERSION.SDK_INT >= 29)
            "${MediaStore.Video.Media.RELATIVE_PATH} = ?" else null
        val args = if (Build.VERSION.SDK_INT >= 29) arrayOf("Movies/Ultra Screen Recorder/") else null
        val items = mutableListOf<Triple<Uri, String, Long>>()
        contentResolver.query(collection, projection, selection, args, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val dateCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val uri = ContentUris.withAppendedId(collection, c.getLong(idCol))
                items.add(Triple(uri, c.getString(nameCol) ?: "Video.mp4", c.getLong(dateCol)))
            }
        }
        if (items.isEmpty()) {
            list.addView(TextView(this).apply { text = "अभी कोई वीडियो नहीं मिला। रिकॉर्डिंग रोकने के बाद यहाँ दिखेगा।"; textSize = 15f })
        }
        items.forEach { (uri, name, _) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
            row.addView(TextView(this).apply { text = name; textSize = 16f })
            val buttons = LinearLayout(this)
            buttons.addView(Button(this).apply {
                text = "▶ Play"
                isAllCaps = false
                setOnClickListener {
                    try {
                        val view = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "video/mp4")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(view)
                    } catch (_: Exception) {
                        Toast.makeText(this@GalleryActivity, "वीडियो प्लेयर नहीं मिला", Toast.LENGTH_SHORT).show()
                    }
                }
            })
            buttons.addView(Button(this).apply {
                text = "Delete"
                isAllCaps = false
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@GalleryActivity)
                        .setMessage("यह वीडियो हटाएँ?")
                        .setPositiveButton("हटाएँ") { _, _ -> contentResolver.delete(uri, null, null); refresh() }
                        .setNegativeButton("रद्द", null).show()
                }
            })
            row.addView(buttons)
            list.addView(row)
        }
    }
}
