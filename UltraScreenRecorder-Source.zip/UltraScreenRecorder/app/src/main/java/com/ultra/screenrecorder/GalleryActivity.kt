package com.ultra.screenrecorder

import android.app.Activity
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.*
import java.io.File

class GalleryActivity : Activity() {
    private lateinit var list: LinearLayout
    private fun folder() = File(getExternalFilesDir(null), "Recordings")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 20, 18, 20) }
        scroll.addView(list)
        setContentView(scroll)
        refresh()
    }
    private fun refresh() {
        list.removeAllViews()
        list.addView(TextView(this).apply { text = "Recordings / आपकी रिकॉर्डिंग"; textSize = 22f; gravity = Gravity.CENTER })
        val files = folder().listFiles()?.filter { it.isFile && it.extension.equals("mp4", true) }?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (files.isEmpty()) list.addView(TextView(this).apply { text = "अभी कोई रिकॉर्डिंग नहीं है"; setPadding(0, 20, 0, 0) })
        files.forEach { f ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
            row.addView(TextView(this).apply { text = f.name; textSize = 16f })
            val actions = LinearLayout(this)
            actions.addView(Button(this).apply { text = "Rename"; isAllCaps = false; setOnClickListener { rename(f) } })
            actions.addView(Button(this).apply { text = "Delete"; isAllCaps = false; setOnClickListener { f.delete(); refresh() } })
            row.addView(actions)
            list.addView(row)
        }
    }
    private fun rename(file: File) {
        val input = EditText(this).apply { setText(file.nameWithoutExtension) }
        android.app.AlertDialog.Builder(this).setTitle("Rename recording").setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim().replace(Regex("[^A-Za-z0-9_-]"), "_")
                if (name.isNotEmpty()) file.renameTo(File(file.parentFile, "$name.mp4"))
                refresh()
            }.setNegativeButton("Cancel", null).show()
    }
}
