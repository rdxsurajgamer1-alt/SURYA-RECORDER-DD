# Ultra Screen Recorder v2.0

This is a larger single-pass Android project package for the requested screen recorder.

## Implemented in this package
- MediaProjection screen capture consent flow.
- Foreground screen recording service and notification.
- MP4 recording with microphone or mute.
- Resolution presets: device, 720p, 1080p, 2K, 4K (limited by device encoder/display).
- Frame-rate presets: 20/30/60/90/120 (limited by encoder; unsupported combinations may fail).
- Bitrate presets.
- Countdown.
- Floating overlay controls (Pause, Resume, Stop; requires Draw over other apps permission).
- Basic recordings list with rename/delete.
- Hindi/English labels in key screens.
- Recording area aspect-ratio selector is included as a UI option, but actual region crop is not yet implemented.
- Facecam toggle is included as a UI option, but camera compositing is not yet implemented.
- Internal audio and internal+microphone are shown as options but currently fall back to silent capture; true playback capture/mixing is not implemented in this package.
- Show touches relies on Android's system Developer Option and is not drawn by the app.
- Drawing/brush overlay is not implemented yet.

## Build
The repository workflow expects this archive to extract into `build-project/UltraScreenRecorder/`.
Run `gradle assembleDebug`.

## Important
This is a development build, not a production release. Test on the target Samsung Galaxy A17 5G / Android 17. Hardware encoders and Android capture policies can reject requested resolutions/FPS. Do not assume all presets are supported.
