# Ultra Screen Recorder

Initial Android project scaffold for the Ultra Screen Recorder app.

- App label: Ultra Screen Recorder
- Languages planned: Hindi + English
- Build: `gradle assembleDebug`

Note: This is a starter scaffold only. It does not yet implement actual screen recording. MediaProjection capture, audio modes, floating controls, crop selection, facecam, and gallery features must be implemented and tested in later steps.
